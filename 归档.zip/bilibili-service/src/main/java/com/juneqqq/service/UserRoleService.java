package com.juneqqq.service;

import com.juneqqq.dao.UserRoleDao;
import com.juneqqq.entity.auth.UserRole;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserRoleService {

    @Resource
    private UserRoleDao userRoleDao;

    public List<UserRole> getUserRoleByUserId(Long userId) {
        return userRoleDao.getUserRoleByUserId(userId);
    }

    public void addUserRole(UserRole userRole) {
        userRoleDao.insert(userRole);
    }
}
