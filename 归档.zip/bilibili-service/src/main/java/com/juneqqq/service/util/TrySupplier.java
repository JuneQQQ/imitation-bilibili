package com.juneqqq.service.util;

public interface TrySupplier<T>{
    T get() throws Throwable;
}
