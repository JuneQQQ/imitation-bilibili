package com.juneqqq.dao;

import com.juneqqq.entity.auth.AuthRole;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
public interface AuthRoleDao {

    AuthRole getRoleByCode(String code);
}
