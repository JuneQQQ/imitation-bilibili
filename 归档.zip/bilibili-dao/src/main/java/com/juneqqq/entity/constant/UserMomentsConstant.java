package com.juneqqq.entity.constant;

import java.util.PrimitiveIterator;

public interface UserMomentsConstant {

    String GROUP_MOMENTS = "MomentsGroup";

    String GROUP_TEST = "TestGroup";

    String GROUP_DANMUS = "DanmusGroup";

    String TOPIC_MOMENTS = "Topic-Moments";

    String TOPIC_DANMUS = "Topic-Danmus";

    String TOPIC_TEST = "Topic-Test";
}
