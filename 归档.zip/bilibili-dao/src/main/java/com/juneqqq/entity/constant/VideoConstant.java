package com.juneqqq.entity.constant;

public interface VideoConstant {
    Long defaultVideoPageSize = 20L;
    Long defaultVideoPageNo = 1L;
}
