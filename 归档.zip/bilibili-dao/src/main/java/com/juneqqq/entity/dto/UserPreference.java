package com.juneqqq.entity.dto;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;

@Data
public class UserPreference {

//    private Long id;

    private Long userId;

    private Long videoId;

    private Float value;

//    @TableField(fill= FieldFill.INSERT)
//    private LocalDateTime createTime;
//    @TableField(fill= FieldFill.INSERT_UPDATE)
//    private LocalDateTime updateTime;

}
