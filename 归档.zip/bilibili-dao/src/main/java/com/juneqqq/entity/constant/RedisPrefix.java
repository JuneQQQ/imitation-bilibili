package com.juneqqq.entity.constant;

public interface RedisPrefix {

    String FILE_FINAL_NAME = "file:hashToUploadId:";
    String FILE_SIZE = "file:size:";
    String USER_SUBSCRIBED = "subscribed:";

    String DANMU_KEY = "dm:video:";
}
