package com.juneqqq.entity.constant;

public interface AuthRoleConstant {

    String ROLE_LV1 = "level1";
    String ROLE_LV2 = "level2";
    String ROLE_LV3 = "level3";
    String ROLE_LV4 = "level4";
    String ROLE_LV5 = "level5";
    String ROLE_LV6 = "level6";
    String SuperAdmin = "super admin";
    String Level1Admin = "level1 admin";
    String Level2Admin = "level2 admin";
    String Level3Admin = "level3 admin";

//    public static final String ROLE_LV1 = "Lv1";
}
